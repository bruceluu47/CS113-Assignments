public class FizzBuzz {

    public static void main(String[] args){

        int[] array = new int[100];

        for(int i = 0; i < array.length; i++){
            array[i] = (i + 1);

            if (array[i] % 3 == 0 && array[i] % 5 == 0){
                System.out.println("FizzBuzz");
            }
            else{
                if(array[i] % 3 == 0){
                    System.out.println("Fizz");
                }
                else{

                    if(array[i] % 5 == 0){
                        System.out.println("Buzz");
                    }
                    else{
                        System.out.println(array[i]);
                    }
                }
            }
        }

    }//end main method

}//end class FizzBuzz
