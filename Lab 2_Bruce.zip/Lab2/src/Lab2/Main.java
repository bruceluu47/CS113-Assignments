package Lab2;

public class Main {

    public boolean powerOfTwo(int num){

        int[] exponents =  new int[31];
        boolean power = false;

        for(int i = 0; i < exponents.length; i++){
            exponents[i] = i + 1;

            if (num == (int)(Math.pow(2, exponents[i]))){
                power = true;
                break;
            }
            else{
                power = false;
            }
        }
        return power;
    }

}
