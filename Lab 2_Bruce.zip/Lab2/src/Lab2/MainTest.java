package Lab2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void powerOfTwo() {
        Main test = new Main();
        boolean output = test.powerOfTwo(128);
        assertEquals(true, output);
    }
}